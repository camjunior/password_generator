package com.example.password_generator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswordGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
